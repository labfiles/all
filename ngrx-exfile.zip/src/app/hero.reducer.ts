import {ActionEx, HeroActionTypes} from './hero.actions';
export const initialState = [];
export function HeroReducer(state = initialState, action: ActionEx) {
  switch (action.type) {
    case HeroActionTypes.Add:
      return [...state, action.payload];
    case HeroActionTypes.Remove:
      return [
        ...state.slice(0, action.payload),
        ...state.slice(action.payload + 1)
      ];
    default:
      return state;
  }
}
