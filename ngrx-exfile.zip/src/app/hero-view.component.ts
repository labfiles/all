import {Component} from '@angular/core';
import {Hero} from './hero';
import {Observable} from 'rxjs';
import {select, Store} from '@ngrx/store';
import {HeroRemove} from './hero.actions';
@Component({
  selector: 'app-heroes-view',
  template : `
  <h4>List of Heroes</h4>
    <ul class="hero">
      <li *ngFor="let hero of heroes | async; let i=index">
        <span >{{i+1}}.</span> {{hero.name}}
        <button style="float: right" (click)="removeHero(i)">Remove</button>
      </li>
    </ul>
  `,
  styles: [`
  .hero {
    margin: 0 0 2em 0;
    list-style-type: none;
    padding: 0;
    width: 15em;
  }
  .hero li {
    background-color: darkslategray;
    color: white;
    padding: 4px;
    margin: 2px;
  }
  
  `]
})
export class HeroesViewComponent {
  heroes: Observable<Hero[]>;
  constructor(private store: Store<{ hero: Hero[] }>) {
    this.heroes = store.pipe(select('hero'));
  }

  removeHero(heroIndex) {
    this.store.dispatch(new HeroRemove(heroIndex));
  }
}
