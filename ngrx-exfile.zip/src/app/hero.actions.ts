import {Action} from '@ngrx/store';
export enum HeroActionTypes {
  Add = '[Hero Component] Add',
  Remove = '[Hero Component] Remove'
}
export class ActionEx implements Action {
  readonly type;
  payload: any;
}
export class HeroAdd implements ActionEx {
  readonly type = HeroActionTypes.Add;
  constructor(public payload: any) {
  }
}
export class HeroRemove implements ActionEx {
  readonly type = HeroActionTypes.Remove;
  constructor(public payload: any) {
  }
}