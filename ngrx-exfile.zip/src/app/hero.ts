export class Hero {
    name: String = '';
  }
  