import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <div style="text-align:center">
    <h1>
      Welcome to {{ title }}!
    </h1>
  </div>
  <app-heroes-view></app-heroes-view>
  <app-hero-add></app-hero-add>
    `
})
export class AppComponent {
  title = 'angular-state-management with NGRX';
}
