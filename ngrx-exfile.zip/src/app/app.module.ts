import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { StoreModule } from '@ngrx/store';

import { AppComponent } from './app.component';
import { HeroesViewComponent } from './hero-view.component';
import { HeroAddComponent } from './hero-add.component';
import { HeroReducer } from './hero.reducer';

@NgModule({
  declarations: [
    AppComponent,
    HeroesViewComponent,
    HeroAddComponent
  ],
  imports: [
    BrowserModule, StoreModule.forRoot({ hero: HeroReducer })

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
