import {Component} from '@angular/core';
import {select, Store} from '@ngrx/store';
import {Hero} from './hero';
import {Observable} from 'rxjs';
import {HeroAdd} from './hero.actions';
@Component({
  selector: 'app-hero-add',
  template : `
   <h4>Add New Hero</h4>
   <input #box ><button (click)="AddHero(box.value)">Add</button>
  `
})
export class HeroAddComponent {
  heroes: Observable<Hero[]>;
  constructor(private store: Store<{ hero: Hero[] }>) {
    this.heroes = store.pipe(select('hero'));
  }
  AddHero(heroName: string) {
    const hero = new Hero();
    hero.name = heroName;
    this.store.dispatch(new HeroAdd(hero));
  }
}
