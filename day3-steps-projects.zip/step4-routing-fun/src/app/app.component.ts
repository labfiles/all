import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <h1>Heroes Application</h1>
  <ul>
  <li>
    <a routerLink="">Batman</a>
  </li>
  <li>
    <a routerLink="superman">Superman</a>
  </li>
  <li>
  <a routerLink="wonderwomen">Wonder Women</a>
  </li>
  </ul>
  <router-outlet></router-outlet>
  `
})
export class AppComponent {
  title = 'step4-routing-fun';
}
