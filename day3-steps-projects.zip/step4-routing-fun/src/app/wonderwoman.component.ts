import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wonderwoman',
  template: `
    <p>
      wonderwoman works!
    </p>
  `,
  styles: []
})
export class WonderwomanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
