import { Component, OnInit, Input } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-header',
  template: `
    
  <ul class="nav justify-content-center navbar navbar-dark bg-dark">
    <li class="nav-item" *ngFor="let hero of herolist">
      <a class="nav-link" href="#">{{ hero.title }}</a>
    </li>
  </ul>
  `,
  styles: []
})
export class HeaderComponent{

  @Input('data') herolist = [];

}
