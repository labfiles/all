import { Component, OnInit } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-root',
  template : `
    <h1>Services Application</h1>
    <app-header [data]="herolist?.data"></app-header>
    <br>
    <app-grid [data]="herolist?.data"></app-grid>
   
  `
})
export class AppComponent{
  title = 'step2-services';
  ver = 0;
  herolist;
  constructor( private hs:HeroService ){
    
  }

  ngOnInit(){
    this.hs.getHeroData().subscribe((res)=>{
        this.herolist = res;
    });
  }
}
