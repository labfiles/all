import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header.component';
import { GridComponent } from './grid.component';
import { HeroService } from './hero.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    GridComponent
  ],
  imports: [
    BrowserModule, HttpClientModule
  ],
  providers: [ HeroService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
