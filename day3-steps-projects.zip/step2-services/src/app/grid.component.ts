import { Component, OnInit, Input } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-grid',
  template: `
  <table  class="table">
  <thead  class="thead-dark">
      <tr>
          <th>SL #</th>
          <th>Order</th>
          <th>Title</th>
          <th>Full Name</th>
          <th>Photo</th>
          <th>City</th>
          <th>Release Date</th>
          <th>Ticket Price</th>
      </tr>
  </thead>
  <tbody>
      <tr *ngFor="let hero of herolist; index as idx; first as fst; last as lst; odd as od; even as ev ">
      <td>{{ idx + 1 }}</td>
      <td>
          <span *ngIf="fst"> First Hero </span>
          <span *ngIf="lst"> Last Hero </span>
          <span *ngIf="!lst && !fst"> Inbetween Hero </span>
          <span *ngIf="ev"> Even Hero </span>
          <span *ngIf="od"> Odd Hero </span>
      </td>
      <td>{{ hero.title | uppercase | lowercase | titlecase }}</td>
      <td>{{ hero.firstname+' '+hero.lastname }}</td>
      <td>
          <img width="50" src="{{ hero.poster }}" alt="{{ hero.title }}">
      </td>
      <td>{{ hero.city }}</td>
      <td>{{ hero.releasedate | date : 'dd-MMMM-yyyy'  }}</td>
      <td>{{ hero.ticketprice | currency : 'INR' }}</td>
      </tr>
  </tbody>
</table>

  `,
  styles: []
})
export class GridComponent {
 
  @Input('data') herolist =[]

}
