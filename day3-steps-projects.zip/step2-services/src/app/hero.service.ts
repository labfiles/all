import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class HeroService{
    constructor(private http:HttpClient){}
    
    getHeroData(){
        return this.http.get("http://localhost:2525/herodata")
        /*
        setTimeout(()=>{
            return this.servicedata;
        }, 1000)
        */
    }

    
}