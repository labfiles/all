import { Component, ViewChild } from '@angular/core';
import { SecondComponent } from './second.component';

@Component({
  selector: 'app-root',
  template : `
  <h1>{{title}}</h1>
  <input type="text" [ngModel]="title" (ngModelChange)="title = $event">
  <br>
  <input #ip type="text" [value]="title" (input)="title = ip.value">
  <br>
  <input type="text" [(ngModel)]="title">
  <hr>
  <!--
  <input type="range" [(ngModel)]="power" >
  <h2>{{ powerDisplay() }}</h2>
  -->
  <h2> {{ power }} </h2>
  <input type="range" [(ngModel)]="power">
  <input type="checkbox" checked="show" (change)="show = !show">
  <app-child *ngIf="show" [power]="power"></app-child>
  <hr>
  <app-second #secondTag></app-second>
  <button (click)="increaseFun()">Increase</button>
  <button (click)="decreaseFun()">Decrease</button>
  `
})
export class AppComponent {
  show = true;
  
  @ViewChild('secondTag',{ static : false }) sc:SecondComponent;

  title = 'step1-binding-communication';
  private _power = 0;
  powerDisplay(){
    return "power now is : "+this._power;
  }
  get power(){
    return this._power;
  }
  set power(npow){
    this._power = npow
  }
  increaseFun(){
    this.sc.increaseScore();
  }
  decreaseFun(){
    this.sc.decreaseScore();
  }
}
