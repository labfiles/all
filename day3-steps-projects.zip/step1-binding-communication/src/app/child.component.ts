import { Component, OnInit, OnChanges, OnDestroy, Input, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
    <p>
      child works!
    </p>
    <h2>Child Comp Power is : {{ power }}</h2>
  `,
  styles: []
})
export class ChildComponent implements OnInit, OnChanges, OnDestroy, AfterViewInit{

  @Input() power = 0;

  constructor() { 
    console.log("Constructor Fired")
  }
  ngOnInit() {
    console.log("ngOnInit Fired")
  }
  ngOnChanges(){
    console.log("ngOnChanges Fired", arguments[0]);
    if(arguments[0].power.currentValue > 10){
      this.power = 10;
    }
  }
  ngOnDestroy(){
    console.log("ngOnDestroy Fired")
  }
  ngAfterViewInit(){
    console.log("ngAfterViewInit Fired")
  }

}
