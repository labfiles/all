import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second',
  template: `
    <h1>Score is : {{ score }}</h1>
  `,
  styles: []
})
export class SecondComponent implements OnInit {

  score = 0;
  constructor() { }

  ngOnInit() {

  }

  increaseScore(){
    this.score++;
  }
  
  decreaseScore(){
    this.score--;
  }

  
}
