import { Component } from "@angular/core";
import { NgForm } from '@angular/forms';

@Component({
    selector : 'app-template-form',
    template : `
    <form #myForm="ngForm" name="myForm" (submit)="formHandler(myForm, $event)" action="#" method="get" novalidate >
        <label for="uname">User Name : </label>
        <input id="uname" #uname="ngModel" name="username" type="text" [(ngModel)]="username" required>
        <br>

        <label for="uage">User Age : </label>
        <input id="uage" #uage="ngModel" name="userage" type="text" [(ngModel)]="userage" min="18" max="80" required>
        <span *ngIf="tooold" >you are too old to join us</span>
        <span *ngIf="tooyoung" >you are too young to join us</span>
        <br>

        <label for="umail">User eMail : </label>
        <input id="umail" #umail="ngModel" pattern=".+@.+" name="usermail" [(ngModel)]="usermail" type="text" required>
        <br>

        <button type="submit">Submit</button>
    </form>
    <ul>
        <li>User Name : {{ username }}</li>
        <li>User Age : {{ userage }}</li>
        <li>User Mail : {{ usermail }}</li>
    </ul>
    <h1>
        Form is 
        <span *ngIf="myForm.valid">Valid</span>
        <span *ngIf="myForm.invalid">Invalid</span>
    </h1>
    <ul>
        <li *ngIf="uname.valid">UserName is Valid</li>
        <li *ngIf="uname.invalid">UserName is Invalid</li>
        <li *ngIf="uname.pristine">UserName is Pristine</li>
        <li *ngIf="uname.dirty">UserName is Dirty</li>
        <li *ngIf="uname.touched">UserName is Touched</li>
        <li *ngIf="uname.untouched">UserName is Untouched</li>
        <li>++++++++++++++++++++++++++++++++++++++</li>
        <li *ngIf="uage.valid">UserAge is Valid</li>
        <li *ngIf="uage.invalid">UserAge is Invalid</li>
        <li *ngIf="uage.pristine">UserAge is Pristine</li>
        <li *ngIf="uage.dirty">UserAge is Dirty</li>
        <li *ngIf="uage.touched">UserAge is Touched</li>
        <li *ngIf="uage.untouched">UserAge is Untouched</li>
        <li>++++++++++++++++++++++++++++++++++++++</li>
        <li *ngIf="umail.valid">User eMail is Valid</li>
        <li *ngIf="umail.invalid">User eMail is Invalid</li>
        <li *ngIf="umail.pristine">User eMail is Pristine</li>
        <li *ngIf="umail.dirty">User eMail is Dirty</li>
        <li *ngIf="umail.touched">User eMail is Touched</li>
        <li *ngIf="umail.untouched">User eMail is Untouched</li>
    </ul>
    `,
    styles : [`
        label{
            width : 100px;
            display : inline-block;
            margin : 3px;
        }
        button{
            width : 100px;
            display : inline-block;
            margin-left : 106px;
        }
        input.ng-invalid.ng-touched{
            border : 4px solid crimson;
        }
        input.ng-valid.ng-touched{
            border : 4px solid darkgreen;
        }
    `]
})
export class TemplateForm{
    username = '';
    userage = '';
    usermail = '';

    
    formHandler(form:NgForm, evt){
        evt.preventDefault();
        if(form.controls.userage.value < 18){
           alert("you are too young to join us");
        }else if(form.controls.userage.value > 80){
           alert("you are too old to join us");
        }else{
            evt.target.submit();
        }
       
    }
}