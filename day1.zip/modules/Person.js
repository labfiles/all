export class Person{
    constructor(cty){
        this.city = cty
    }
};