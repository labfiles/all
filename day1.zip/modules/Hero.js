import { Person } from  "./Person.js";

export class Hero extends Person{
    constructor(fname, lname, cty){
        super(cty);
        this.firstname = fname;
        this.lastname = lname;
        this._secret = "top mission";
    }
    fullname(){
        return this.firstname+" "+this.lastname;
    }
    get secret(){
        return this._secret;
    }
    set secret(newmission){
        this._secret = newmission
    }
};