let express = require("express");
let app = express();
    app.use(express.static(__dirname));
    app.get("/", function(req, res){
       // res.send("hello from express")
        res.sendFile(__dirname+"/step13-using-typescript-modules.html");
    })
    app.listen(5050);
    console.log("server is now live on localhost:5050")