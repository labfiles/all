import Person from  "./Person.js";

export class Hero extends Person{
    _secret:string;
    constructor(public firstname:string, public lastname:string, cty:string){
        super(cty);
        this._secret = "top mission";
    }
    fullname():string{
        return this.firstname.toUpperCase()+" "+this.lastname.toUpperCase();
    }
    get secret():string{
        return this._secret;
    }
    set secret(newmission){
        this._secret = newmission
    }
};