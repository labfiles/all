export default class Person{
    city:string
    constructor(cty:string){
        this.city = cty
    }
};