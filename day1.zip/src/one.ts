interface iPerson{
    city:string;
}
class Person implements iPerson{
    city:string
    constructor(cty:string){
        this.city = cty
    }
};
interface iHero{
    firstname:string;
    lastname:string;
    fullname():string;
};

class Hero extends Person implements iHero{
    private _secret:string
    constructor(  public firstname:string, 
                  public lastname:string, 
                  private cty:string){
        super(cty);

        this._secret = "top mission";
    }
    fullname():string{
        return this.firstname+" "+this.lastname;
    }
    get secret():string{
        return this._secret;
    }
    set secret(newmission){
        this._secret = newmission
    }
};
var hero1 = new Hero("Tony", "Stark", "New York" );
var hero2 = new Hero("Kit", "Walker", "Bangala");
var hero3 = new Hero("Steve", "Rogers", "New York");
console.log(hero1.firstname, hero1.lastname, hero1.fullname(), hero1.secret, hero1.city );
hero1.secret = "mission changed";
console.log(hero1.secret);