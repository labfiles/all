"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Person = /** @class */ (function () {
    function Person(cty) {
        this.city = cty;
    }
    return Person;
}());
;
;
var Hero = /** @class */ (function (_super) {
    __extends(Hero, _super);
    function Hero(firstname, lastname, cty) {
        var _this = _super.call(this, cty) || this;
        _this.firstname = firstname;
        _this.lastname = lastname;
        _this.cty = cty;
        _this._secret = "top mission";
        return _this;
    }
    Hero.prototype.fullname = function () {
        return this.firstname + " " + this.lastname;
    };
    Object.defineProperty(Hero.prototype, "secret", {
        get: function () {
            return this._secret;
        },
        set: function (newmission) {
            this._secret = newmission;
        },
        enumerable: true,
        configurable: true
    });
    return Hero;
}(Person));
;
var hero1 = new Hero("Tony", "Stark", "New York");
var hero2 = new Hero("Kit", "Walker", "Bangala");
var hero3 = new Hero("Steve", "Rogers", "New York");
console.log(hero1.firstname, hero1.lastname, hero1.fullname(), hero1.secret, hero1.city);
hero1.secret = "mission changed";
console.log(hero1.secret);
