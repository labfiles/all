var Person = /** @class */ (function () {
    function Person(cty) {
        this.city = cty;
    }
    return Person;
}());
export default Person;
;
