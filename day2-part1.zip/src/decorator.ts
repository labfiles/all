function Component(config:any){
    return function(targetClass:any){
        return class {
            title = new targetClass().title;
            tag = config.selector;
            content = config.template;
        }
    }
}
@Component({
    selector : "app-root",
    template : "<h1>Welcome to your life</h1>"
})
class Hero{
    title = "Batman";
};