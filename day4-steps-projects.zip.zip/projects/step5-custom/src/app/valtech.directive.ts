import { Directive, OnInit, ElementRef, Input } from '@angular/core';

@Directive({
    selector : 'valtech'
})
export class ValtechDirective implements OnInit{
    @Input() valtech;
    content = ''
    constructor(private elRef:ElementRef){}
    ngOnInit(){
        // this.elRef.nativeElement.innerHTML = "Valtech";
        /*
        */
       
        this.elRef.nativeElement.addEventListener("click", function(evt){
            alert(evt.target.getAttribute("data"))
        });
        // this.elRef.nativeElement.outerHTML = "<"+this.valtech+">"+elm.innerHTML+"</"+this.valtech+">";
    }
    
}