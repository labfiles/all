import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name : 'gen'
})
export class GenPipe implements PipeTransform{

    transform(val, prefix){
        if(prefix === 'male'){
            return "Mr. "+val
        }else{
            return "Miss. "+val
        }
    }

}