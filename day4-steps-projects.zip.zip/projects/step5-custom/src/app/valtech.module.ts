import { NgModule } from '@angular/core';
import { GenPipe } from './gen.pipe';
import { ValtechDirective } from './valtech.directive';

@NgModule({
    declarations : [ GenPipe, ValtechDirective],
    exports : [GenPipe, ValtechDirective]
})
export class ValtechModule{

}