import { Component, Inject } from "@angular/core";
import { AppService } from "./app.service";
import { HERO_TOKEN } from "./app.it.service";

@Component({
    selector : 'app-one-comp',
    template : `
        <h1>{{ title }} {{ appServ.num }}</h1>
        <h2>App Name : {{ appname | json }}</h2>
        <hr>
        <ul><li *ngFor="let hero of herolist" >{{ hero }}</li></ul>
    `
})
export class OneComponent{
    title = "Hello from One Component"
    herolist = [];
    
  constructor(
    private appServ:AppService, 
    @Inject(HERO_TOKEN) private appname
    ){}
  ngOnInit(){
    this.herolist = this.appServ.getData();
  }
}