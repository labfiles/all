import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { OneComponent } from './one.component';
import { TwoComponent } from './two.component';
import { AppService } from './app.service';
import { HERO_TOKEN } from './app.it.service';
import { val } from './valtech.values';
// import { val } from './valtech.values';

// let user = 'guest';

@NgModule({
  declarations: [ AppComponent, OneComponent, TwoComponent],
  imports: [ BrowserModule, FormsModule ],
  providers: [
    { provide : AppService , useClass : AppService},
    { provide : HERO_TOKEN , useExisting : AppService}
    // { provide : HERO_TOKEN , useValue : val}
    /*
      { provide : HERO_TOKEN, useFactory: function(){
          if(!guest){
            return new HeroService()
          }else{
            return new MockService()
          }
      }}
    */
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
