import { InjectionToken } from "@angular/core";

export const HERO_TOKEN = new InjectionToken<any>('')