import { Component } from "@angular/core";
import { AppService } from "./app.service";

@Component({
    selector : 'app-two-comp',
    template : `
        <h1>{{ title }} {{ appServ.num }}</h1>
        <hr>
        <ul>
          <li *ngFor="let hero of herolist" >{{ hero }}</li>
        </ul>
    `
})
export class TwoComponent{
    title = "Hello from Two Component"
    herolist = [];
  constructor(private appServ:AppService){}
  ngOnInit(){
    this.herolist = this.appServ.getData();
  }
}