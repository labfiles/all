import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batman',
  template: `
    <p>
      batman works!
    </p>
  `,
  styles: []
})
export class BatmanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
