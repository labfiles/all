import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-ironman',
  template: `
    <h1> ironman works! {{ productUnits || 0}} </h1>
  `,
  styles: []
})
export class IronmanComponent implements OnInit {
  productUnits;
  constructor( private ar:ActivatedRoute) { }
  
  ngOnInit() {
    this.productUnits = this.ar.snapshot.params['units'];
  }

}
