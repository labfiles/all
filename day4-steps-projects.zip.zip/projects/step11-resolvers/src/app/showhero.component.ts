import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    template:`
    <a [routerLink]="['']">Back to List</a> 
    <h2> Show Details </h2>
    <h1>{{ heroes.name }}</h1>
    <hr>
    `
  })
  export class ShowHero implements OnInit{
    selhero = 0;
    filterherodata = '';
    heroes; 
    constructor(private ar:ActivatedRoute ){};
    ngOnInit() {
        // this.selhero = this.ar.snapshot.queryParams['hid'];
        // this.ar.queryParams.subscribe( res => {
        //   this.selhero = res['hid']
        // })
        // this.filterherodata = this.ar.snapshot.queryParams['filterdata'];
        // this.heroes = this.hd.getSingleData(this.selhero);
        // // console.log(this.selhero)

        this.ar.data.subscribe( res => {
          this.heroes = res["singleherodata"];
          console.log(this.heroes);
        })
    }; 
  } 