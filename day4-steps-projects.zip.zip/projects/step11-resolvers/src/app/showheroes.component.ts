import { Component } from '@angular/core';
import { HeroServices } from './hero.service';
import { ActivatedRoute } from '@angular/router';
import { HeroResolverservice } from './heroresolver.service';

@Component({
    template:`
    <h2> {{ apptitle }} </h2>
    <table border="1" width="100%">
    	<thead>
    		<tr>
    			<td>Sl #</td>
    			<td>Title</td>
    			<td>Real Name</td>
    			<td>More Details</td>
    		</tr>
    	</thead>
    	<tbody>
        <tr *ngFor="let hero of heroes">
          <td>{{ hero.id }}</td>
          <td>{{ hero.name }}</td>
          <td>{{ hero.biography["full-name"] }}</td>
          <td>
            <a 
            [routerLink]="['hero']"
            [queryParams]="{ hid : hero.id}">Details</a>
          </td>
          <!--td>
            <a 
            [routerLink]="['hero', hero.id]">Details</a>
          </td-->
        </tr>
    	</tbody>
    </table>
    `
  })
  export class ShowHeroes{
    heroes;
    apptitle = "";
    constructor(private ar:ActivatedRoute ){ 
    } 
    ngOnInit(){
        // this.heroes = this.ar.snapshot.data["herodata"].heroes;
        this.ar.data.subscribe( res => {
          this.apptitle = res["apptitle"];
          this.heroes = res["herodata"].heroes;
        })
    }
    
  }