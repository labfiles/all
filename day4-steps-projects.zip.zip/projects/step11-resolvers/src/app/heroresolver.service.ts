import { Injectable } from "@angular/core";
import { Resolve } from "@angular/router";
import { HeroServices } from "./hero.service";

@Injectable()
export class HeroResolverservice implements Resolve<any>{
    constructor( private hs:HeroServices){}
    resolve( ){
        return this.hs.getData();
    }

}