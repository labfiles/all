import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { ShowHeroes } from './showheroes.component';
import { ShowHero } from './showhero.component';
import { HeroPipe } from './hero.pipe';
import { HeroServices } from './hero.service';
import { HeroResolverservice } from './heroresolver.service';
import { SingleHeroResolverservice } from './singleheroresolver.service';

@NgModule({
  declarations: [ AppComponent,ShowHeroes,ShowHero, HeroPipe ],
  imports: [ BrowserModule, RouterModule.forRoot([
    {  path : "", 
       component:ShowHeroes, 
       data:{ apptitle : "Hello Valtech" },
       resolve : { herodata : HeroResolverservice }
      },
      {path : "hero", component:ShowHero,
      resolve : { singleherodata : SingleHeroResolverservice }
      },
  ]) ],
  providers: [HeroServices, HeroResolverservice, SingleHeroResolverservice],
  bootstrap: [AppComponent]
})
export class AppModule { }
